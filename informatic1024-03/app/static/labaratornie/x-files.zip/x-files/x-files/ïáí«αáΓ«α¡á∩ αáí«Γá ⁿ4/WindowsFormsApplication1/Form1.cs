﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization; //сериализация
using System.Runtime.Serialization.Formatters.Binary; //сериализация
using System.IO; //сериализация


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        int keyopen;
        Form2 f2;
        public Form1()
        {
            InitializeComponent();
        }

        public void proverkaOpen()
        {
            keyopen = MdiChildren.Length; //проверка: открыта ли в настоящее время дочерняя форма в роительской форме?
            if (keyopen == 0)
            {               
                saveToolStripMenuItem.Enabled = false; //блокировка меню "Сохранить"
                saveAsToolStripMenuItem.Enabled = false; //блокировка меню "Сохранить как"
            }

            if (keyopen > 0)
            {
                saveToolStripMenuItem.Enabled = true; //разблокировка меню "Сохранить"
                saveAsToolStripMenuItem.Enabled = true; //разблокировка меню "Сохранить как"
                f2 = (Form2)this.ActiveMdiChild; // возвращает объект Form, который представляет дочернее окно текущего активного интерфейса
                if (f2.flagIzmen==false) //если дочерняя форма не изменялась с момента открытия
                {
                    saveToolStripMenuItem.Enabled = false; //блокировка меню "Сохранить"          
                }
            }
        }

        public void saveFile(Form2 f) // функция сохранения файла
        {
            string fileName;
            List<Figure> array; //объект array класса Figure
            f2 = f;
            BinaryFormatter formatter1 = new BinaryFormatter(); //Сохранение объекта obj некоторого класса X в файле с именем fileName 
            if (f2.fileName == null) //Имя файла, выбранное в диалоговом окне файла - если раньше этот файл не был сохранен
            {
                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.InitialDirectory = Environment.CurrentDirectory; //При инициализации файловых диалогов указываем в качестве стартового каталога текущий каталог программы
                saveFileDialog1.Filter = "Графический редактор(*.alx)|*.alx|All files (*.*)|*.*"; //Задаем текущую строку фильтра имен файлов, которая определяет варианты, которые появляются в окне "сохранить как тип файла" или "файлы типа" в диалоговом окне
                saveFileDialog1.FilterIndex = 1; //Задаем индекс фильтра, выбранного в настоящий момент в диалоговом окне файла.
                if (saveFileDialog1.ShowDialog() == DialogResult.OK) //если нажали OK
                {
                    fileName = saveFileDialog1.FileName;
                    array = f2.array;                    
                    Stream myStream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None);
                    formatter1.Serialize(myStream, array);
                    myStream.Close();
                    f2.flagIzmen = false;
                    f2.fileName = fileName;
                    f2.Text = Path.GetFileName(saveFileDialog1.FileName);
                }
            }
            else //Имя файла, выбранное в диалоговом окне файла -если раньше этот файл был сохранен
            {
                fileName = f2.fileName;
                array = f2.array;
                Stream myStream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None);
                formatter1.Serialize(myStream, array);
                myStream.Close();
                f2.flagIzmen = false;                              
            }
        }
        
        private void newToolStripMenuItem_Click(object sender, EventArgs e) //меню "Создать"
        {
            f2 = new Form2();
            f2.MdiParent = this;
            f2.Text = "Рисунок " + this.MdiChildren.Length.ToString();
            f2.Show();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e) //меню "Открыть"
        {
            Stream myStream = null;
            string fileName;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "Графический редактор(*.alx)|*.alx|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;            
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try // содержит защищенный код, который может вызвать исключение; выполняется, пока не возникнет исключение или пока он не будет успешно завершен.
                {
                    if ((myStream = openFileDialog1.OpenFile()) != null)
                    {
                        using (myStream)
                        {                                                       
                            fileName = openFileDialog1.FileName;
                            BinaryFormatter formatter1 = new BinaryFormatter(); // Восстановление сохранённого объекта из файла:                           
                            Stream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                            List<Figure> array = (List<Figure>)formatter1.Deserialize(stream);                            
                            stream.Close();
                            myStream.Close();
                            f2 = new Form2();                            
                            f2.MdiParent = this;
                            f2.fileName = fileName;                            
                            f2.Text = openFileDialog1.SafeFileName;
                            f2.array = array;
                            f2.Show();
                            f2.flagIzmen = false;                            
                        }
                    }
                }
                catch (Exception ex) //исключение - если такого файла не существует
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e) //меню "Сохранить"
        {
            saveFile((Form2)this.ActiveMdiChild);
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e) //меню "Сохранить как"
        {
            f2 = (Form2)this.ActiveMdiChild;
            f2.fileName = null;
            saveFile((Form2)this.ActiveMdiChild);
        }

        private void fileToolStripMenuItem_DropDownOpened(object sender, EventArgs e) //блокировка меню "Сохранить" и "Сохранить как"
        {
            proverkaOpen();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
    }
}
