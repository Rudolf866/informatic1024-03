﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;


namespace WindowsFormsApplication1
{

    [Serializable()] public partial class Form2 : Form
    {        
        Point p1, p2;
        bool Flag=false;
        Figure Rc1,Rc2;
        Form1 f1;
        public bool flagIzmen = false;
        public string fileName = null;
        //public bool flagName = false;
        internal List<Figure> array;        
        public Form2()
        {
            InitializeComponent();
            array = new List<Figure>();             
        }
        private void Form2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {                
                Flag = true;
                p1 = new Point(e.X, e.Y);
                p2 = p1;
             }
        }

        private void Form2_MouseMove(object sender, MouseEventArgs e)
        {
            Graphics g = CreateGraphics();            
            if (Flag)
            {
                Rc2 = new Rect(p1, p2);
                p2 = new Point(e.X, e.Y);
                Rc1 = new Rect(p1, p2);
                Rc2.Hide(g);            
                Rc1.DrawDash(g);
            }
            g.Dispose();
        }

        private void Form2_MouseUp(object sender, MouseEventArgs e)
        {
            Graphics g = CreateGraphics();
            if (Flag)
            {               
                p2 = new Point(e.X, e.Y);
                Rc1 = new Rect(p1, p2);
                Rc1.Draw(g);
                array.Add(Rc1);
                flagIzmen = true;
            }
            Flag = false;
            g.Dispose(); 
            Invalidate();
        }

        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            if (array != null)
            {
                foreach (Figure f in array)
                {
                    Graphics g = CreateGraphics();
                    f.Draw(g);
                    g.Dispose();                    
                }
            }
        }
        
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (flagIzmen)
            {
                DialogResult result;
                result = MessageBox.Show("Сохранить изменения в \"" + this.Text + "\"", "Графический редактор Alex's", MessageBoxButtons.YesNoCancel);
                switch (result)
                {
                    case DialogResult.Yes:
                        {
                            f1 = new Form1();
                            f1.saveFile(this);
                            break;
                        }
                    case DialogResult.Cancel:
                        {
                            e.Cancel = true;
                            return;
                        }
                }
            }
        }
      /*  public List massiv()
        {
            massiv = array;
            Form f1 = new Form1();
            f1.Show(this);
        }*/
    }
}
