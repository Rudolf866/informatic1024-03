﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Runtime.Serialization; //пространства имён, применяемых при сериализации
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace WindowsFormsApplication1
{
    /*сериализация*/
    [Serializable()] class Rect : Figure //дочерний класс для рисования прямоугольников
    {
        public Rect(Point point1, Point point2) : base(point1, point2)//конструктор дочернего класса
        {

        }
        public override void Draw(Graphics g) //реализация метода рисования
        {
            norm(ref x1, ref y1, ref x2, ref y2);
            Pen P1 = new Pen(Color.Black, 1);
            Rectangle r = Rectangle.FromLTRB(x1, y1, x2, y2);
            g.DrawRectangle(P1, r);
        }
        public override void DrawDash(Graphics g)//реализация метода рисования пунктиром
        {
            norm(ref x1, ref y1, ref x2, ref y2);
            Pen P2 = new Pen(Color.Black, 1);
            P2.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            Rectangle r = Rectangle.FromLTRB(x1, y1, x2, y2);
            g.DrawRectangle(P2, r);
        }
        public override void Hide(Graphics g)//реализация метода стирания
        {
            norm(ref x1, ref y1, ref x2, ref y2);
            Pen P3 = new Pen(Color.White, 1);
            Rectangle r = Rectangle.FromLTRB(x1, y1, x2, y2);
            g.DrawRectangle(P3, r);
        }
    }
}
