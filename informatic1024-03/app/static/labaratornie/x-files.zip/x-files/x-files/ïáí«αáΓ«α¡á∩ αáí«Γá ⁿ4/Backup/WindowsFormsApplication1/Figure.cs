﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace WindowsFormsApplication1
{
    [Serializable()] abstract class Figure
    {
        protected int x1,x2,y1,y2,x,y;
        public abstract void Draw(Graphics g);
        public abstract void DrawDash(Graphics g);
        public abstract void Hide(Graphics g);
        public void MouseMove(Graphics g,int newX, int newY)
        {

        }
        public void norm(ref int x1, ref int y1, ref int x2, ref int y2)
        {
            if (x1>x2) { x = x2; x2 = x1; x1 = x; }
            if (y1>y2) { y = y2; y2 = y1; y1 = y; }
        }
        public Figure(Point point1, Point point2)
        { x1 = point1.X; y1 = point1.Y; x2 = point2.X; y2 = point2.Y; }
    }
    [Serializable()] class Rect : Figure
    {
        public Rect(Point point1, Point point2) : base(point1, point2) { }
        public override void Draw(Graphics g)
        {
            norm(ref x1, ref y1, ref x2, ref y2);
            Pen P1 = new Pen(Color.Black, 1); 
            Rectangle r = Rectangle.FromLTRB(x1, y1, x2, y2);
            g.DrawRectangle(P1, r);
        }
        public override void DrawDash(Graphics g)
        {
            norm(ref x1, ref y1, ref x2, ref y2);
            Pen P2 = new Pen(Color.Black, 1);
            P2.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            Rectangle r = Rectangle.FromLTRB(x1, y1, x2, y2);
            g.DrawRectangle(P2, r);
        }
        public override void Hide(Graphics g)
        {
            norm(ref x1, ref y1, ref x2, ref y2);
            Pen P3 = new Pen(Color.White, 1);
            Rectangle r = Rectangle.FromLTRB(x1, y1, x2, y2);
            g.DrawRectangle(P3, r);
        }
    }
}
