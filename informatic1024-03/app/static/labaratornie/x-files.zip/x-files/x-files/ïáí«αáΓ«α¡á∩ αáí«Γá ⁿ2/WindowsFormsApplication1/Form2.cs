﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        private int x1, y1, x2, y2, k;
        private bool f;
        private Graphics g;
        public Form2()
        {
            InitializeComponent();
    }
       
        private void Form2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                g = CreateGraphics();
                f = true;
                x1 = e.X;
                y1 = e.Y;
                x2 = e.X;
                y2 = e.Y;
            }
            else f = false;
            }

        private void Form2_MouseMove(object sender, MouseEventArgs e)
        {
            if (f)
            {
                Pen pen2 = new Pen(Color.White, 3);
                g.DrawRectangle(pen2, x1, y1, x2, y2);
                x2 = e.X;
                y2 = e.Y;
                if (x1 >= x2)
                {
                    k = x1;
                    x1 = x2;
                    x2 = k;
                }
                if (y1 >= y2)
                {
                    k = y1;
                    y1 = y2;
                    y2 = k;
                }
                Pen pen = new Pen(Color.Black, 3);
                pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                g.DrawRectangle(pen, x1, y1, x2, y2);
            }
        }

        private void Form2_MouseUp(object sender, MouseEventArgs e)
        {
            if (f)
            {
                Pen pen2 = new Pen(Color.White, 3);
                g.DrawRectangle(pen2, x1, y1, x2, y2);

                Pen pen = new Pen(Color.Black, 3);
                g.DrawRectangle(pen, x1, y1, x2, y2);
                g.Dispose();
            }
            f = false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
