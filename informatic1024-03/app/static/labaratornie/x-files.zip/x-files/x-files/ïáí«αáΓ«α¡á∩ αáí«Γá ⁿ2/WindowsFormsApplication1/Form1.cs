﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
      
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left){
                Graphics g = CreateGraphics();
                string s = e.X.ToString() + ";" + e.Y.ToString();
                g.DrawString(s, new Font("Times New Roman", 8),
                    new SolidBrush(Color.Black), new Point(e.X, e.Y));

            }
            if (e.Button == MouseButtons.Right) {
                MessageBox.Show("Нажата правая кнопка мыши", "Диалоговое окно");
                Graphics g = CreateGraphics();
                g.Clear(Color.White);

            }
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f = new Form2();
            f.MdiParent = this;
            f.Text = "Рисунок " + this.MdiChildren.Length.ToString();
            f.Show();
        }

        private void windowToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
