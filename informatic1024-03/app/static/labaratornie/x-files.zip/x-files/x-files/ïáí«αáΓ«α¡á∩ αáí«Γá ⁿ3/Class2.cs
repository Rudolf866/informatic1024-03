﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace WindowsFormsApplication3
{
    class Rect : Figure
    {
       
        private int x1, x2, y1, y2;

        public Rect(int X, int Y, MouseEventArgs e)
            : base(X, Y)
        {
            if (e.X < X) { x2 = X; x1 = e.X; } else { x1 = X; x2 = e.X; }
            if (e.Y < Y) { y2 = Y; y1 = e.Y; } else { y1 = Y; y2 = e.Y; }
        }

        public override void DrawDash(Graphics g)//рисование пунктиром
        {
            Pen pen1 = new Pen(Color.Black, 1);
            pen1.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            Rectangle rect = new Rectangle(x1, y1, x2 - x1, y2 - y1);
            g.DrawRectangle(pen1, rect);
        }

        public override void Hide(Graphics g)//стирание
        {
            Pen pen1 = new Pen(Color.White, 1);
            Rectangle rect = new Rectangle(x1, y1, x2 - x1, y2 - y1);
            g.DrawRectangle(pen1, rect);
        }

        public override void Draw(Graphics g)//рисование
        {
            Pen pen1 = new Pen(Color.Black, 1);
            Rectangle rect = new Rectangle(x1, y1, x2 - x1, y2 - y1);
            g.DrawRectangle(pen1, rect);
        }
    }
}
