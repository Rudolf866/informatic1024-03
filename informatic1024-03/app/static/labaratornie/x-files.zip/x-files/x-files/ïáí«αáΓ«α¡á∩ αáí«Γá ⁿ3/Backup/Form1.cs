﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {

            Graphics g = CreateGraphics();
            Graphics q = CreateGraphics();
            Graphics lt = CreateGraphics();

            //q.Clear(Color.White);

            string OX = e.X.ToString();
            string OY = e.Y.ToString();



            if (e.Button == MouseButtons.Left) 
            {
                lt.DrawString(OX, new Font("Times New Roman", 19),
                new SolidBrush(Color.Black), new Point(e.X, e.Y));
                lt.DrawString(OY, new Font("Times New Roman", 19),
                new SolidBrush(Color.Black), new Point(e.X+40, e.Y));
            
            }
            if (e.Button == MouseButtons.Right)
            {
                string s = "Нажата правая кнопка!";
                g.DrawString(s, new Font("Times New Roman", 19),
                new SolidBrush(Color.Black), new Point(140, 200));

                MessageBox.Show(s);
                q.Clear(Color.White);
            }
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f = new Form2();
            f.MdiParent = this;
            f.Text = "Рисунок " + this.MdiChildren.Length.ToString();
            f.Show();

        }

    }
}
