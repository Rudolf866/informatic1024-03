﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form2 : Form
    {

        public Form2()
        {
            InitializeComponent();
        }

        List<Figure> array = new List<Figure>(); 
        bool flag = false, flagMove = false;
        MouseEventArgs pE;
        int X, Y;

        private void Form2_MouseDown(object sender, MouseEventArgs e)
        {
            flag = true;
            X = e.X;
            Y = e.Y;
        }

        private void Form2_MouseMove_1(object sender, MouseEventArgs e)
        {
            if (flag == true)
            {
                if (flagMove == false) pE = e;
                Graphics g = CreateGraphics();
                Rect rectangleH = new Rect(X, Y, pE);
                Rect rectangle = new Rect(X, Y, e);
                rectangleH.Hide(g);
                rectangle.DrawDash(g);
                pE = e;
                flagMove = true;
            }
        }

        private void Form2_MouseUp_1(object sender, MouseEventArgs e)
        {
            flagMove = false;
            flag = false;
            Graphics g = CreateGraphics();
            Rect rectangle = new Rect(X, Y, e);
            rectangle.Draw(g);

            array.Add(rectangle);
            foreach (Figure rect in array)
            {
                rect.Draw(g);
            }
        }
    }
}

