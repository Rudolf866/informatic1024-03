﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace WindowsFormsApplication3
{
    
    abstract class Figure
    {
        
        protected int X, Y;

       
        public Figure(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
        }

        public abstract void Draw(Graphics g);
        public abstract void DrawDash(Graphics g);
        public abstract void Hide(Graphics g);
    }
}
