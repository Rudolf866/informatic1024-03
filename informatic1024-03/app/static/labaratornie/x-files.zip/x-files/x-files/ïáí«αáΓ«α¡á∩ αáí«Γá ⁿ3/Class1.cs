﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace WindowsFormsApplication3
{
    
    abstract class Figure
    {

        protected int X, Y;//информация о начальной точке


        public Figure(int X, int Y)//конструктор класса, получающий эту точку в качестве аргументов
        {
            this.X = X;
            this.Y = Y;
        }

        public abstract void Draw(Graphics g);//рисование
        public abstract void DrawDash(Graphics g);//рисование пунктиром
        public abstract void Hide(Graphics g);//стирание фигуры
    }
}
