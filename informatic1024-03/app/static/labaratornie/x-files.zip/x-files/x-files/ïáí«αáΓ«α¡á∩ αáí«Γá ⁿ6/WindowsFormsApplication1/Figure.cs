﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace WindowsFormsApplication1
{
    [Serializable()] abstract class Figure
    {
        protected int x1, x2, y1, y2, x, y, bS1;
        protected Color cL1, cF1;
        public abstract void Draw(Graphics g);//рисование
        public abstract void DrawDash(Graphics g);//рисование пунктиром
        public abstract void Hide(Graphics g);//стирание фигуры
        public void MouseMove(Graphics g, int newX, int newY)//перемещение мыши
        {

        }
        public void norm(ref int x1, ref int y1, ref int x2, ref int y2) //вспомогательный метод для нормализации координат прямоугольника; ref обеспечивает передачу аргумента по ссылке, а не по значению
        {
            if (x1 > x2) { x = x2; x2 = x1; x1 = x; }
            if (y1 > y2) { y = y2; y2 = y1; y1 = y; }
        }
        public Figure(Point point1, Point point2, int bS, Color cL, Color cF)//конструктор баового класса фигур
        {
            x1 = point1.X; y1 = point1.Y; x2 = point2.X; y2 = point2.Y;
            bS1 = bS; cL1 = cL; cF1 = cF;
        }
    }
   
}
