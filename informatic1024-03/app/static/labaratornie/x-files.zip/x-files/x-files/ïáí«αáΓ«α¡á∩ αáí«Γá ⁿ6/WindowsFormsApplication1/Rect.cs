﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace WindowsFormsApplication1
{
    [Serializable()]class Rect : Figure //дочерний класс для рисования прямоугольников
    {
        public Rect(Point point1, Point point2, int bS, Color cL, Color cF) : base(point1, point2, bS, cL, cF) { }//конструктор дочернего класса

        public override void Draw(Graphics g)//реализация метода рисования
        {
            norm(ref x1, ref y1, ref x2, ref y2);
            Pen P1 = new Pen(cL1, bS1);
            SolidBrush SB = new SolidBrush(cF1);
            Rectangle r = Rectangle.FromLTRB(x1, y1, x2, y2);
            g.FillRectangle(SB, r); //Заполняет внутреннюю часть прямоугольника, определяемого структурой Rectangle.
            g.DrawRectangle(P1, r);
        }
        public override void DrawDash(Graphics g)//реализация метода рисования пунктиром
        {
            norm(ref x1, ref y1, ref x2, ref y2);
            Pen P2 = new Pen(cL1, bS1);
            P2.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            Rectangle r = Rectangle.FromLTRB(x1, y1, x2, y2);
            g.DrawRectangle(P2, r);
        }
        public override void Hide(Graphics g)//реализация метода стирания
        {
            norm(ref x1, ref y1, ref x2, ref y2);
            Pen P3 = new Pen(Color.White, bS1);
            Rectangle r = Rectangle.FromLTRB(x1, y1, x2, y2);
            g.DrawRectangle(P3, r);
        }
    }
}
