﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        int keyopen;
        Form2 f2; 
        public int brushSize, brushSize1;
        public Color colorLine, colorFon;
        public Form1()
        {
            colorLine = Color.Black;     
            colorFon = Color.White;     
            brushSize = 1;              
            InitializeComponent();
        }

        public void proverkaOpen()      
        {
            keyopen = MdiChildren.Length;   
            if (keyopen == 0)               
            {               
                saveToolStripMenuItem.Enabled = false;      
                saveAsToolStripMenuItem.Enabled = false;    
            }

            if (keyopen > 0)    
            {
                saveToolStripMenuItem.Enabled = true;       
                saveAsToolStripMenuItem.Enabled = true;
                f2 = (Form2)this.ActiveMdiChild;          
                if (f2.flagIzmen==false)                    
                {
                    saveToolStripMenuItem.Enabled = false;                   
                }
            }
        }

        public void saveFile(Form2 f)   
        {
            string fileName;
            List<Figure> array;
            f2 = f; 
            BinaryFormatter formatter1 = new BinaryFormatter();
            if (f2.fileName == null)    
            {
                SaveFileDialog saveFileDialog1 = new SaveFileDialog();                  
                saveFileDialog1.InitialDirectory = Environment.CurrentDirectory;        
                saveFileDialog1.Filter = "Графический редактор(*.alx)|*.alx|All files (*.*)|*.*";   
                saveFileDialog1.FilterIndex = 1;                                        
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)                 
                {
                    fileName = saveFileDialog1.FileName;                    
                    array = f2.array;                                                         
                    Stream myStream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None); 
                    formatter1.Serialize(myStream, array);                  
                    myStream.Close();                                       
                    f2.flagIzmen = false;                                 
                    f2.fileName = fileName;                               
                    f2.Text = Path.GetFileName(saveFileDialog1.FileName);  
                }
            }
            else    
            {
                fileName = f2.fileName; 
                array = f2.array;
                Stream myStream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None);
                formatter1.Serialize(myStream, array);
                myStream.Close();
                f2.flagIzmen = false;                              
            }
        }
        
        private void newToolStripMenuItem_Click(object sender, EventArgs e)    
        {
            NFDialog myDialog = new NFDialog();
            DialogResult result = myDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                f2 = new Form2();
                f2.MdiParent = this;                                        
                f2.Text = "Рисунок " + this.MdiChildren.Length.ToString();  
                f2.Height = myDialog.vysota;
                f2.Width = myDialog.shirina;
                f2.Show();                                                  
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)    
        {
            Stream myStream = null; 
            string fileName;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();              
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "Графический редактор(*.alx)|*.alx|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;            
            if (openFileDialog1.ShowDialog() == DialogResult.OK)               
            {
                try 
                {
                    if ((myStream = openFileDialog1.OpenFile()) != null)        
                    {
                        using (myStream)
                        {                                                       
                            fileName = openFileDialog1.FileName;
                            BinaryFormatter formatter1 = new BinaryFormatter();                            
                            Stream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                            List<Figure> array = (List<Figure>)formatter1.Deserialize(stream);                          
                            stream.Close(); 
                            myStream.Close();
                            f2 = new Form2();                                                           
                            f2.MdiParent = this;
                            f2.fileName = fileName;                            
                            f2.Text = openFileDialog1.SafeFileName;
                            f2.array = array;                                   
                            f2.Show();                                          
                            f2.flagIzmen = false;                                                 
                        }
                    }
                }
                catch (Exception ex)  
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);    
                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)  
        {
            saveFile((Form2)this.ActiveMdiChild);   
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)  
        { 
            f2 = (Form2)this.ActiveMdiChild;        
            f2.fileName = null;                     
            saveFile((Form2)this.ActiveMdiChild);   
        }

        private void fileToolStripMenuItem_DropDownOpened(object sender, EventArgs e)    
        {
            proverkaOpen();     
        }

        private void brushSizeToolStripMenuItem_Click(object sender, EventArgs e)   
        {
            BrushSize myDialog = new BrushSize();                           
            DialogResult result = myDialog.ShowDialog(this);                
            if (result == DialogResult.OK) brushSize = myDialog.vybor;      
        }

        private void colorLineToolStripMenuItem_Click(object sender, EventArgs e) 
        {
            ColorDialog myDialog = new ColorDialog();                           
            DialogResult result = myDialog.ShowDialog();
            if (result == DialogResult.OK) colorLine = myDialog.Color;              
        }

        private void colorFonToolStripMenuItem_Click(object sender, EventArgs e)    
        {
            ColorDialog myDialog = new ColorDialog(); 
            DialogResult result = myDialog.ShowDialog();
            if (result == DialogResult.OK) colorFon = myDialog.Color;             
        }
    }
}
