﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class NFDialog : Form
    {
        public int vysota, shirina;
        public NFDialog()
        {
            InitializeComponent();
            checkBox1.Checked = false;            
            TextEnFalse();
        }

        private void TextEnFalse()
        {
            label1.Enabled = false; label2.Enabled = false;
            textBox1.Enabled = false; textBox2.Enabled = false;
            radioButton1.Enabled = true; radioButton2.Enabled = true; radioButton3.Enabled = true;
            button1.Enabled = true;
            
        }

        private void TextEnTrue()
        {
            label1.Enabled = true; label2.Enabled = true;
            textBox1.Enabled = true; textBox2.Enabled = true;
            radioButton1.Enabled = false; radioButton2.Enabled = false; radioButton3.Enabled = false;
            if (textBox1.Text != "" && textBox2.Text != "") button1.Enabled = true;
            else button1.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked) TextEnTrue();
            else TextEnFalse();            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                try 
                {
                    shirina = Convert.ToInt32(textBox1.Text);
                    vysota = Convert.ToInt32(textBox2.Text);
                    this.Close();
                }
                catch (Exception ex) 
                {
                    MessageBox.Show(ex.Message);   
                    return;
                }

            }
            else
            {
                if (radioButton1.Checked) { shirina = 320; vysota = 240; }
                if (radioButton2.Checked) { shirina = 640; vysota = 480; }
                if (radioButton3.Checked) { shirina = 800; vysota = 600; }
            }            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            ProverkaText(e);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            ProverkaText(e);
        }

        private static void ProverkaText(KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) == false && e.KeyChar != '\b')
            {
                e.Handled = true;
                return;
            }           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            TextEnTrue();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            TextEnTrue();
        }
    }
}
