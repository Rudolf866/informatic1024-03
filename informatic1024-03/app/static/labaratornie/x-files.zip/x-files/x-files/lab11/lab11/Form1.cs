﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Draw(int x, int y)
        {
            Graphics g = CreateGraphics();
            string str = "по Х:" + x.ToString() + "     по У:" + y.ToString();
            g.DrawString(str, new Font("Lucida Console", 10), new SolidBrush(Color.White), new Point(x, y));
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Draw(e.X, e.Y);
            }
            else if (e.Button == MouseButtons.Right)
            {
                Graphics g = CreateGraphics();
                MessageBox.Show("Нажата правая кнопка мыши", "Alert");
                g.Clear(Color.Red);
            }
        }
    }
}

